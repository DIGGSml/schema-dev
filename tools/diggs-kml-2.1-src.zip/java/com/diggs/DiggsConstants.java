package com.diggs;

/**
 * Constants
 * 
 */
public class DiggsConstants {

    /**
     * Folder containing the the properties file
     */
    public final static String CONF_FOLDER = "../conf";

    /**
     * Folder containing the image files
     */
    public final static String CONF_IMG_FOLDER = "img";

    /**
     * Folder containing the xslt files
     */
    public final static String CONF_XSL_FOLDER = "xsl";

    /**
     * Intermediate file suffix
     */
    public final static String INTERMEDIATE_FILE_SUFFIX = ".temp";

    /**
     * The SRS converter XSLT
     */
    public final static String CONF_XSL_SRS_CONVERTER_FILE_NAME = "srsConverter.xsl";

    /**
     * The KML Styling file name
     */
    public final static String KML_STYLING_FILE_NAME = "DIGGS_KML_STYLING.xml";

    /**
     * The XSLT parameter for specifying the KML styling file
     */
    public final static String XSLT_PARAMETER_KML_STYLING_FILE = "DIGGS_KML_STYLING_FILE";

    /**
     * The XSLT parameter for specifying the KML styling file
     */
    public final static String TARGET_IMAGERY_FOLDER = "TARGET_IMAGERY_FOLDER";

    /**
     * The XSLT parameter for specifying the target SRS
     */
    public final static String XSLT_PARAMETER_TARGET_SRS_NAME = "TARGET_SRS_NAME";

    /**
     * The CRS to EPSG properties file
     */
    public final static String CRS2EPSG_PROPERTIES_FILE_XML = "crsAuthorityCodeEPSGMapping.xml";

    /**
     * The DIGGS configuration file
     */
    public final static String CONFIGURATION_PROPERTIES = "configuration.properties";

    /**
     * The DIGGS SRS URN separator in the configuration file
     */
    public final static String CONFIGURATION_PROPERTIES_SPPORTED_SRS_URN_SEPARATOR = ",";

    /**
     * The EPSG code prefix
     */
    public final static String EPSG_CODE_PREFIX = "EPSG:";

    /**
     * The separator between two KML coordinates tuples (x x1 x2)
     */
    public final static String KML_COORDINATE_TUPLE_SEPARATOR = " ";

    /**
     * The separator between two KML coordinate (e.g. x,y,z)
     */
    public final static String KML_COORDINATE_SEPARATOR = ",";

    /**
     * The KML compound CRS name
     */
    public final static String KML_COMPOUND_CRS_NAME = "urn:ogc:def:crs:OGC:LonLat84_5773";

    /**
     * The separator between GML coordinates
     */
    public final static String GML_COORDINATE_SEPARATOR = " ";

    /**
     * The name of the raised overlay image
     */
    public final static String RAISED_OVERLAY_IMAGE_NAME = "GroundOverlayRaised.jpg";

    //
    // Configuration file parameter
    //

    /**
     * The configuration property for the DIGGS SRS supported URN
     */
    public final static String CONFIGURATION_PROPERTIES_SUPPORTED_SRS_URN = "supported.srs.urn";

    /**
     * The configuration property for the default srsName for 2D coordinates
     */
    public final static String CONFIGURATION_PROPERTIES_DEFAULT_2D_SRSNAME = "default.2d.srsName";

    /**
     * The configuration property for the default srsName for 3D coordinates
     */
    public final static String CONFIGURATION_PROPERTIES_DEFAULT_3D_SRSNAME = "default.3d.srsName";

    /**
     * The configuration property for the DIGGS WKT properties file
     */
    public final static String CONFIGURATION_PROPERTIES_WKT_PROPERTIES_FILE = "wkt.properties";

    /**
     * The configuration property for transforming all coordinates to
     * (Meter,Meter,Meter)
     */
    public final static String CONFIGURATION_PROPERTIES_WORLD_UTM_SRSNAME = "world.utm.srsName";

    /**
     * The configuration property for the tile server
     */
    public final static String CONFIGURATION_PROPERTIES_TILE_SERVER = "tile.server";

    /**
     * The configuration property for the outputed kml file
     */
    public final static String CONFIGURATION_PROPERTIES_REMOVE_TEMPORARY_OUTPUT = "remove.temporary.output";

}