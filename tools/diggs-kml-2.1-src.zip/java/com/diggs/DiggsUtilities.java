package com.diggs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import org.opengis.referencing.crs.CoordinateReferenceSystem;
import org.opengis.referencing.cs.AxisDirection;
import org.opengis.referencing.cs.CoordinateSystemAxis;

import com.diggs.crs.configuration.ConfigurationLoader;
import com.diggs.crs.transformation.geotools.GTCoordinateTransformer;

public class DiggsUtilities {

    /**
     * Returns the dimension for the specified SRS name
     * 
     * @param srsName
     * @return
     * @throws Exception
     */
    public static String getDimensionFromSRS(String srsName) throws Exception {
        return GTCoordinateTransformer.getInstance().getDimensionFromSRS(
                srsName);
    }

    /**
     * Converts the specified coordinates to the target SRS
     * 
     * @param coordinates
     *            the original coordinates
     * @param srsName
     *            the name of the source spatial reference system
     * @param srsDimensionAsString
     *            the dimension of the source spatial reference system
     * @param targetSrsName
     *            the target srs to convert the data to
     * @return the list of coordinates as supported by the specified target SRS
     * @throws Exception
     */
    public static String convertToTargetCoordinates(String coordinates,
            String srsName, String srsDimensionAsString, String targetSrsName)
            throws Exception {

        if (targetSrsName.equals(DiggsConstants.KML_COMPOUND_CRS_NAME)) {
            return GTCoordinateTransformer.getInstance().convertToKML(
                    coordinates, srsName, srsDimensionAsString);
        } else {
            return GTCoordinateTransformer.getInstance().convertCoordinates(
                    coordinates, srsName, srsDimensionAsString, targetSrsName);
        }

    }

    /**
     * Downloads the raised overlay for the specified bounding box and returns
     * the tile boundaries as {SOUTH,WEST NORTH,EAST}
     * 
     * @param north
     * @param south
     * @param east
     * @param west
     * @param imageFolder
     * @throws Exception
     */
    public static String getRaisedOverlayTile(double north, double south,
            double east, double west, String imageFolder) throws Exception {

        // download the image file from the server and store it under the image
        // folder

        // start at a highest zoom level
        int zoom = 4;

        // tile values
        int swTilex = 0;
        int swTiley = 0;
        int neTilex = 0;
        int neTiley = 0;

        // degree per tile
        double lonDegreePerTile = 0.0;
        double latDegreePerTile = 0.0;

        // boolean to compare if the tiles are identical
        // if the tiles are different decrease the zoom level
        boolean sameTile = false;

        // loop until the tiles are identical
        while (!sameTile && zoom > 0) {

            // Calculate the number of degrees used per tile
            lonDegreePerTile = 360.0 / (10 * Math.pow(2.0, (double) zoom));
            latDegreePerTile = 180.0 / (5 * Math.pow(2.0, (double) zoom));

            // System.out.println("lonDegreePerTile " + lonDegreePerTile);
            // System.out.println("latDegreePerTile " + latDegreePerTile);

            //
            // Calculate the tiles x/y values for the given coordinates
            //

            swTilex = new Double((west + 180) / lonDegreePerTile).intValue();
            swTiley = new Double((south + 90) / latDegreePerTile).intValue();

            neTilex = new Double((east + 180) / lonDegreePerTile).intValue();
            neTiley = new Double((north + 90) / latDegreePerTile).intValue();

            // compare tiles
            if (swTilex == neTilex && swTiley == neTiley) {
                sameTile = true;
                break;
            } else {
                //
                zoom--;
            }
        }

        // String urlAsString =
        // "http://worldwind25.arc.nasa.gov/tile/tile.aspx?T=bmng.topo.bathy.200401&L=0&X=1&Y=3";
        String urlAsString = ConfigurationLoader
                .getInstance()
                .getPropertiesFiles()
                .getConfiguration()
                .getProperty(
                        DiggsConstants.CONFIGURATION_PROPERTIES_TILE_SERVER)
                + "&L=" + zoom + "&X=" + swTilex + "&Y=" + swTiley;

        // System.out.println(urlAsString);

        try {
            URL url = new URL(urlAsString);

            URLConnection uc = url.openConnection();
            InputStream content = (InputStream) uc.getInputStream();

            File trgFileFolder = new File(imageFolder);

            if (!trgFileFolder.exists()) {
                trgFileFolder.mkdir();
            }

            File trgFile = new File(imageFolder + File.separator
                    + DiggsConstants.RAISED_OVERLAY_IMAGE_NAME);

            if (!trgFile.exists()) {
                trgFile.createNewFile();
            }

            OutputStream out = new FileOutputStream(trgFile);

            byte[] buf = new byte[1024];

            int len;
            while ((len = content.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            content.close();
            out.close();

        } catch (Exception e) {
            System.err.println("WARNING: Unable to retrieve the tile");
            e.printStackTrace();
        }

        // calculate tile boundary
        double tileMinx = swTilex * lonDegreePerTile - 180;
        double tileMiny = swTiley * latDegreePerTile - 90;
        double tileMaxx = (swTilex + 1) * lonDegreePerTile - 180;
        double tileMaxy = (swTiley + 1) * latDegreePerTile - 90;

        // System.out.println("tileMinx " + tileMinx);
        // System.out.println("tileMiny " + tileMiny);
        // System.out.println("tileMaxx " + tileMaxx);
        // System.out.println("tileMaxy " + tileMaxy);

        // return the tiles bbox

        // create tile bbox as {SOUTH,WEST NORTH,EAST}
        String tileBBox = tileMiny + DiggsConstants.KML_COORDINATE_SEPARATOR
                + tileMinx + DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR
                + tileMaxy + DiggsConstants.KML_COORDINATE_SEPARATOR + tileMaxx;

        // return "49.76574743426339,-7.557133175464009
        // 49.76688112240979,-7.556579044862011";
        return tileBBox;
    }

    /**
     * Returns the KML coordinates for the given position on this location
     * 
     * @param locationCoordinates
     *            as KMl coordinates
     * @param positionOnTheLocation
     * @param positionOnTheLocationDimension
     * 
     * @return
     */
    public static String resolveLinearReferencing(String locationCoordinates,
            String positionOnTheLocations,
            double positionOnTheLocationDimension, String vectorOffset,
            String vectorOffsetSRS) throws Exception {

        // System.out.println("locationCoordinates " +
        // locationCoordinates);
        // System.out.println("positionOnTheLocations " +
        // positionOnTheLocations);
        // System.out.println("positionOnTheLocationDimension " +
        // positionOnTheLocationDimension);

        // coordinates string to return
        String positionOnTheLocationsAsCoordinates = "";

        // We can parametrize the 3D linestrings (e.g. Borehole centerline) by
        // arc-length, then work out the z-value.

        // Control Points are tuples defining the location geometry (e.g.
        // borehole linestring (CP1, CP2, ... CPn))
        // Total distance: L = ||CPn-CP1||
        // Intermediate cumulative distance: di = ||CPi-CP1||
        // Parameterized segment is as follows f(t)= (1-((t-di)/L))*P1 +
        // (((t-di)/L)*P2) when di <= t

        // tokenize all location coordinates
        StringTokenizer locationCoordinatesTuples = new StringTokenizer(
                locationCoordinates,
                DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR);

        // list of tuples as coordinates
        List<String> locationCoordinatesTuplesList = new ArrayList<String>();
        while (locationCoordinatesTuples.hasMoreTokens()) {
            // convert (Deg,Deg,Met) to (Met,Met,Met)
            String utmCoordinates = GTCoordinateTransformer.getInstance()
                    .convertKMLTuple(
                            locationCoordinatesTuples.nextToken(),
                            GTCoordinateTransformer.getInstance()
                                    .getKmlCoordinateReferenceSystem(),
                            GTCoordinateTransformer.getInstance()
                                    .getWorldUTMreferenceSystem());
            // add to location coordinates list
            locationCoordinatesTuplesList.add(utmCoordinates);
        }

        // retrieve total number of tuple
        int numberOfLocationCoordinatesTuples = locationCoordinatesTuplesList
                .size();
        // System.out.println("numberOfLocationCoordinatesTuples "
        // + numberOfLocationCoordinatesTuples);

        // CP1(x1, y1, z1)
        String cp1 = locationCoordinatesTuplesList.get(0);

        // list of cumulative distances
        List<Double> cumulativeDistances = new LinkedList<Double>();

        double previousCumulativeDistances = 0;
        double newCumulativeDistances = 0;
        String previousTuple = null;

        for (String tuple : locationCoordinatesTuplesList) {

            if (previousTuple == null) {
                // first tuple
                previousTuple = tuple;
            }

            // System.out.println("previousTuple " + previousTuple);
            // System.out.println("tuple " + tuple);

            newCumulativeDistances = calculateDistance(previousTuple, tuple);
            previousCumulativeDistances += newCumulativeDistances;

            // System.out.println("Adding newCumulativeDistances "
            // + newCumulativeDistances);
            // System.out.println("Adding cumulativeDistances "
            // + previousCumulativeDistances);

            cumulativeDistances.add(previousCumulativeDistances);

            // cumulativeDistances.add(calculateDistance(cp1, tuple));
        }

        // tokenize position
        StringTokenizer positionOnTheLocationsTokens = new StringTokenizer(
                positionOnTheLocations,
                DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR);

        // determine vector offset direction
        boolean offsetDirectionIsEasting = false;
        if (vectorOffsetSRS != null && vectorOffsetSRS.length() > 0) {

            CoordinateReferenceSystem vectorCRS = GTCoordinateTransformer
                    .getInstance().getCRSFromAuthorithyCode(vectorOffsetSRS);
            if (vectorCRS != null) {
                CoordinateSystemAxis axis = vectorCRS.getCoordinateSystem()
                        .getAxis(0);

                if (axis != null) {
                    if (axis.getDirection() == AxisDirection.EAST
                            || axis.getDirection() == AxisDirection.EAST_NORTH_EAST
                            || axis.getDirection() == AxisDirection.EAST_SOUTH_EAST
                            || axis.getDirection() == AxisDirection.WEST
                            || axis.getDirection() == AxisDirection.WEST_NORTH_WEST
                            || axis.getDirection() == AxisDirection.WEST_SOUTH_WEST) {

                        offsetDirectionIsEasting = true;
                    }
                }
            }
        }

        // use offset
        double vectorOffsetX = 0;
        double vectorOffsetY = 0;
        double vectorOffsetZ = 0;
        double vectorOffsetUnit = 0;
        // if an offset has been specified
        if (vectorOffset != null && vectorOffset.length() > 0) {
            StringTokenizer vectorOffsetTokens = new StringTokenizer(
                    vectorOffset, DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR);

            if (offsetDirectionIsEasting) {
                vectorOffsetX = new Double(vectorOffsetTokens.nextToken());
                vectorOffsetY = new Double(vectorOffsetTokens.nextToken());
            } else {
                vectorOffsetY = new Double(vectorOffsetTokens.nextToken());
                vectorOffsetX = new Double(vectorOffsetTokens.nextToken());
            }
            vectorOffsetZ = new Double(vectorOffsetTokens.nextToken());
            vectorOffsetUnit = Math.sqrt(Math.pow((vectorOffsetX), 2)
                    + Math.pow((vectorOffsetY), 2)
                    + Math.pow((vectorOffsetZ), 2));

            // System.out.println("vectorOffsetX " + vectorOffsetX);
            // System.out.println("vectorOffsetY " + vectorOffsetY);
            // System.out.println("vectorOffsetZ " + vectorOffsetZ);
            // System.out.println("vectorOffsetUnit " + vectorOffsetUnit);
        }

        // for each position specified
        while (positionOnTheLocationsTokens.hasMoreTokens()) {

            // position as double (position on the linear reference)
            double positionOnTheLocation = new Double(
                    positionOnTheLocationsTokens.nextToken());

            // System.out
            // .println("positionOnTheLocation " + positionOnTheLocation);

            int indexOfStartControlPoint = 0;
            int indexOfEndControlPoint = 1;
            // determine the start control points to use
            while (true) {
                if (cumulativeDistances.get(indexOfStartControlPoint) <= positionOnTheLocation
                        && (positionOnTheLocation < cumulativeDistances
                                .get(indexOfEndControlPoint))) {
                    break;
                } else {
                    // increase start and end location
                    indexOfStartControlPoint++;
                    indexOfEndControlPoint++;

                    // if indexOfEndControlPoint is > size of
                    // locationCoordinatesTuplesList, just use the last element
                    // this can be due to some precision issues
                    if (indexOfEndControlPoint == numberOfLocationCoordinatesTuples) {
                        indexOfStartControlPoint--;
                        indexOfEndControlPoint--;
                        break;
                    }
                }
            }

            // System.out.println("indexOfStartControlPoint "
            // + indexOfStartControlPoint);
            // System.out.println("indexOfEndControlPoint "
            // + indexOfEndControlPoint);

            // get start and end control points
            String startControlPoint = locationCoordinatesTuplesList
                    .get(indexOfStartControlPoint);
            String endControlPoint = locationCoordinatesTuplesList
                    .get(indexOfEndControlPoint);
            // get the cumulative distance
            double cumulativeDistance = cumulativeDistances
                    .get(indexOfStartControlPoint);

            // System.out.println("startControlPoint " + startControlPoint);
            // System.out.println("endControlPoint " + endControlPoint);
            // System.out.println("cumulativeDistance " + cumulativeDistance);

            StringTokenizer startControlPointToken = new StringTokenizer(
                    startControlPoint, DiggsConstants.KML_COORDINATE_SEPARATOR);
            double x1 = new Double(startControlPointToken.nextToken());
            double y1 = new Double(startControlPointToken.nextToken());
            double z1 = new Double(startControlPointToken.nextToken());
            StringTokenizer endControlPointToken = new StringTokenizer(
                    endControlPoint, DiggsConstants.KML_COORDINATE_SEPARATOR);
            double x2 = new Double(endControlPointToken.nextToken());
            double y2 = new Double(endControlPointToken.nextToken());
            double z2 = new Double(endControlPointToken.nextToken());

            // System.out.println("x1 " + x1);
            // System.out.println("y1 " + y1);
            // System.out.println("z1 " + z1);
            // System.out.println("x2 " + x2);
            // System.out.println("y2 " + y2);
            // System.out.println("z2 " + z2);
            // System.out
            // .println("positionOnTheLocation " + positionOnTheLocation);

            double searchedX = 0;
            double searchedY = 0;
            double searchedZ = 0;

            // resolve the searched position
            // f(t)= (1-((t-di)/L))*P1 + (((t-di)/L)*P2) when di <= t

            // determine remaining position
            double remainingPosition = positionOnTheLocation
                    - cumulativeDistance;

            // calculate distance between points
            // calculate total distance: L = ||CP2-CP1||
            double l = calculateDistance(x1, y1, z1, x2, y2, z2);

            // System.out.println("positionOnTheLocation from starting point "
            // + (remainingPosition));
            // System.out.println("distance between control point " + (l));

            searchedX = ((1 - ((remainingPosition) / l)) * x1)
                    + ((remainingPosition / l) * x2);
            searchedY = ((1 - ((remainingPosition) / l)) * y1)
                    + ((remainingPosition / l) * y2);
            searchedZ = ((1 - ((remainingPosition) / l)) * z1)
                    + ((remainingPosition / l) * z2);

            // System.out.println("searchedX before offset " + searchedX);
            // System.out.println("searchedY before offset " + searchedY);
            // System.out.println("searchedZ before offset " + searchedZ);

            if (positionOnTheLocationDimension == 2) {
                // if an offset has been specified
                if (vectorOffsetUnit != 0.0) {
                    // position as double (position related to the offset)
                    double offsetPosition = new Double(
                            positionOnTheLocationsTokens.nextToken());

                    // System.out.println("offsetPosition " + offsetPosition);

                    // f1(t)= f(t) + (t1*(offsetVector/||offsetVector||)) when
                    // di <= t

                    searchedX += (offsetPosition * ((vectorOffsetX / vectorOffsetUnit)));
                    searchedY += (offsetPosition * ((vectorOffsetY / vectorOffsetUnit)));
                    searchedZ += (offsetPosition * ((vectorOffsetZ / vectorOffsetUnit)));
                }

            } else if (positionOnTheLocationDimension > 2) {
                throw new Exception("Linear Referencing of dimension '"
                        + positionOnTheLocationDimension
                        + "' are not  supported");
            }

            // System.out.println("searchedX after offset " + searchedX);
            // System.out.println("searchedY after offset " + searchedY);
            // System.out.println("searchedZ after offset " + searchedZ);

            // create KML coordinates for the searched position
            String searchedPositionCoordinates = searchedX
                    + DiggsConstants.KML_COORDINATE_SEPARATOR + searchedY
                    + DiggsConstants.KML_COORDINATE_SEPARATOR + searchedZ;

            // System.out.println("searchedPositionCoordinates "
            // + searchedPositionCoordinates);

            // we might have to convert (Met,Met,Met) to (Deg,Deg,Met)
            searchedPositionCoordinates = GTCoordinateTransformer.getInstance()
                    .convertKMLTuple(
                            searchedPositionCoordinates,
                            GTCoordinateTransformer.getInstance()
                                    .getWorldUTMreferenceSystem(),
                            GTCoordinateTransformer.getInstance()
                                    .getKmlCoordinateReferenceSystem());

            // System.out.println("searchedPositionCoordinates "
            // + searchedPositionCoordinates);

            positionOnTheLocationsAsCoordinates += searchedPositionCoordinates;
            positionOnTheLocationsAsCoordinates += DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR;
        }

        // return result
        return positionOnTheLocationsAsCoordinates.trim();
    }

    /**
     * Calculates the distance between two 3D coordinates
     * 
     * @param start
     * @param end
     * @return
     */
    private static double calculateDistance(String start, String end) {

        // tokenize start element
        StringTokenizer cp1 = new StringTokenizer(start,
                DiggsConstants.KML_COORDINATE_SEPARATOR);
        double x1 = new Double(cp1.nextToken());
        double y1 = new Double(cp1.nextToken());
        double z1 = new Double(cp1.nextToken());

        // tokenize end element
        StringTokenizer cpn = new StringTokenizer(end,
                DiggsConstants.KML_COORDINATE_SEPARATOR);
        double x2 = new Double(cpn.nextToken());
        double y2 = new Double(cpn.nextToken());
        double z2 = new Double(cpn.nextToken());

        // calculate total distance: L = ||CPn-CP1||
        double distance = calculateDistance(x1, y1, z1, x2, y2, z2);

        // return distance
        // System.out.println("distance " + distance);
        return distance;
    }

    /**
     * Calculate the distance between the specified points
     * 
     * @param x1
     * @param y1
     * @param z1
     * @param x2
     * @param y2
     * @param z2
     * @return
     */
    private static double calculateDistance(double x1, double y1, double z1,
            double x2, double y2, double z2) {

        // calculate total distance: L = ||CPn-CP1||
        double distance = Math.sqrt(Math.pow((x2 - x1), 2)
                + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));

        // return distance
        // System.out.println("distance " + distance);
        return distance;
    }

}
