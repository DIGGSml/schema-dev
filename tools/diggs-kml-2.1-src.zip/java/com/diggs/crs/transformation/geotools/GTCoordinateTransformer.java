package com.diggs.crs.transformation.geotools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.geotools.factory.BasicFactories;
import org.geotools.factory.FactoryRegistryException;
import org.geotools.factory.Hints;
import org.geotools.referencing.CRS;
import org.geotools.referencing.ReferencingFactoryFinder;
import org.geotools.referencing.crs.DefaultCompoundCRS;
import org.geotools.referencing.operation.DefaultCoordinateOperationFactory;
import org.opengis.referencing.FactoryException;
import org.opengis.referencing.crs.CRSAuthorityFactory;
import org.opengis.referencing.crs.CRSFactory;
import org.opengis.referencing.crs.CompoundCRS;
import org.opengis.referencing.crs.CoordinateReferenceSystem;
import org.opengis.referencing.crs.SingleCRS;
import org.opengis.referencing.crs.VerticalCRS;
import org.opengis.referencing.operation.CoordinateOperation;
import org.opengis.referencing.operation.MathTransform;
import org.opengis.referencing.operation.TransformException;

import com.diggs.DiggsConstants;
import com.diggs.crs.configuration.ConfigurationLoader;

/**
 * This class provides utilities to convert coordinates
 */
public class GTCoordinateTransformer {

    /**
     * Map of additional Coordinate Reference Systems (CRS). Key is Authority
     * Code, Value is CRS definition as WKT.
     */
    private Properties authorityCode2Wkt;

    /**
     * Map of supported and defined Coordinate Reference Systems (CRS). Key is
     * Authority Code, Value is EPSG code.
     */
    private Properties authorityCode2EPSGCode;

    /**
     * Global configuration file
     */
    private Properties configuration;

    /**
	 * 
	 */
    private List<String> supportedSRSURNs;

    /**
     * EPSGCRSAuthorityFactory instance of all the default EPSG codes defined in
     * geotools
     */
    private CRSAuthorityFactory epsgcrsAuthorithyFactory;

    /**
     * Default 2D SRS name
     */
    private String default2DSrsName;

    /**
     * Default 3D SRS name
     */
    private String default3DSrsName;

    /**
     * KML CoordinateReferenceSystem
     */
    private CoordinateReferenceSystem kmlCoordinateReferenceSystem;

    /**
     * The world UTM srsName to use for transforming all coordinates to
     * (Meter,Meter,Meter)
     */
    private String worldUTMSrsName;

    /**
     * The world UTM CoordinateReferenceSystem to use for transforming all
     * coordinates to (Meter,Meter,Meter)
     */
    private CoordinateReferenceSystem worldUTMreferenceSystem;

    /**
     * Singleton instance of GTCoordinateTransformer
     */
    private static GTCoordinateTransformer instance;

    /**
     * The coordinate operation factory
     */
    DefaultCoordinateOperationFactory operationFactory;

    /**
     * Maps of currently transformed geometry. key
     * ={sourceSrsName+targetSrsName+coordinates}, value=transformed value. this
     * will avoid to reconvert the same coordinates everytime. This map msu tbe
     * cleared for every new execution by using the clearGeometryCache method
     */
    private Map<String, String> transformationCache = new HashMap<String, String>();

    /**
     * The coordinate operation factory hints
     */
    private static final Hints DIGGS_HINTS = new Hints();
    static {
        // http://docs.geotools.org/latest/javadocs/org/geotools/factory/Hints.html
        DIGGS_HINTS.put(Hints.LENIENT_DATUM_SHIFT, Boolean.TRUE);
        DIGGS_HINTS.put(Hints.FORCE_LONGITUDE_FIRST_AXIS_ORDER, Boolean.TRUE);

        // DATUM_SHIFT_METHOD, etc.
    }

    public GTCoordinateTransformer() throws Exception {
        // load properties
        loadProperties();
        // load EPSG authority factory
        epsgcrsAuthorithyFactory = ReferencingFactoryFinder
                .getCRSAuthorityFactory("EPSG", DIGGS_HINTS);
        // create KML CRS
        kmlCoordinateReferenceSystem = getKMLCoordinateReferenceSystem();
        // create World UTM CRS to use for transforming all coordinates to
        // (Meter,Meter,Meter)
        worldUTMreferenceSystem = getCRSFromAuthorithyCode(worldUTMSrsName);
        // Factory to create transformations from a source and target CS
        operationFactory = new DiggsDefaultCoordinateOperationFactory(
                DIGGS_HINTS);
    }

    /***************************************************************************
     * Returns the KML CRS
     * 
     * @return
     * @throws Exception
     */
    private CoordinateReferenceSystem getKMLCoordinateReferenceSystem()
            throws Exception {

        // TODO create KML compound CRS - c.f. Annex B of KML 2.2. specification
        // reverse lon/let - DB needs to valid this

        // //
        // // create the GeodeticCRS
        // //
        //
        // // create urn:ogc:def:axis:OGC:Long axis
        // CoordinateSystemAxis axisLon = new
        // DefaultCoordinateSystemAxis("Long",
        // AxisDirection.EAST, NonSI.DEGREE_ANGLE);
        // // create urn:ogc:def:axis:OGC:Lat axis
        // CoordinateSystemAxis axisLat = new
        // DefaultCoordinateSystemAxis("Lat",AxisDirection.NORTH,
        // NonSI.DEGREE_ANGLE);
        //
        // // create urn:ogc:def:cs:OGC:LonLatEllipsoidalCS
        // EllipsoidalCS ellipsoidalCS = new DefaultEllipsoidalCS(
        // "Ellipsoidal 2D CS. Axes: longitude, latitude. Orientations: east,
        // north. UoM: deg",axisLon, axisLat);
        // // create WGS84 datum
        // GeodeticDatum geodeticDatum = DefaultGeodeticDatum.WGS84;
        // // create urn:ogc:def:crs:OGC:LonLat84
        // GeodeticCRS geodeticCRS = new DefaultGeographicCRS(geodeticDatum,
        // ellipsoidalCS);
        //
        // //
        // // create the VerticalCRS
        // //
        //
        // // create verticalCS
        // VerticalCS verticalCS = DefaultVerticalCS.GRAVITY_RELATED_HEIGHT;
        // // create verticalDatum
        // VerticalDatum verticalDatum = DefaultVerticalDatum.GEOIDAL;
        // // create urn:ogc:def:crs:EPSG:5773
        // VerticalCRS verticalCRS = new DefaultVerticalCRS(verticalDatum,
        // verticalCS);
        // // create new array
        // CoordinateReferenceSystem[] array = new CoordinateReferenceSystem[2];
        // array[0] = geodeticCRS;
        // array[1] = verticalCRS;

        // create KML compound CRS - c.f. Annex B of KML 2.2. specification
        // reverse lon/let
        CoordinateReferenceSystem geodeticCRS = CRS.decode("EPSG:4326", true);
        CoordinateReferenceSystem verticalCRS = CRS.decode("EPSG:5773");
        // create new array
        CoordinateReferenceSystem[] array = new CoordinateReferenceSystem[2];
        array[0] = geodeticCRS;
        array[1] = verticalCRS;

        // create CompoundCRS
        CompoundCRS compoundCRS = new DefaultCompoundCRS(
                DiggsConstants.KML_COMPOUND_CRS_NAME, array);

        // System.out.println(compoundCRS.toWKT());

        // return the CompoundCRS
        return compoundCRS;
    }

    /**
     * Returns the singleton instance of this class
     * 
     * @return
     * @throws IOException
     */
    public static GTCoordinateTransformer getInstance() throws Exception {
        if (instance == null) {
            instance = new GTCoordinateTransformer();
        }
        return instance;
    }

    /**
     * Removed any cached transformation
     * 
     */
    public void clearGeometryCache() {
        transformationCache.clear();
    }

    /**
     * Constructor
     * 
     * @throws Exception
     */
    private void loadProperties() throws Exception {

        // Load CRS to WKT mapping
        authorityCode2Wkt = ConfigurationLoader.getInstance()
                .getPropertiesFiles().getAuthorityCode2Wkt();
        // Load CRS to EPSG mapping if not already loaded
        authorityCode2EPSGCode = ConfigurationLoader.getInstance()
                .getPropertiesFiles().getAuthorityCode2EPSGCode();
        // Load configuration
        configuration = ConfigurationLoader.getInstance().getPropertiesFiles()
                .getConfiguration();
        // Load supported SRS URNs
        supportedSRSURNs = loadSupportedSRSURNs(configuration);
        // Load default SRS names
        default2DSrsName = configuration
                .getProperty(DiggsConstants.CONFIGURATION_PROPERTIES_DEFAULT_2D_SRSNAME);
        default3DSrsName = configuration
                .getProperty(DiggsConstants.CONFIGURATION_PROPERTIES_DEFAULT_3D_SRSNAME);
        // Retrieve the srs to use for transforming all coordinates to
        // (Meter,Meter,Meter)
        worldUTMSrsName = configuration
                .getProperty(DiggsConstants.CONFIGURATION_PROPERTIES_WORLD_UTM_SRSNAME);

    }

    /**
     * <p>
     * Loads the support SRS URNs
     * </p>
     * 
     */
    private List<String> loadSupportedSRSURNs(Properties configuration) {
        String urns = configuration
                .getProperty(DiggsConstants.CONFIGURATION_PROPERTIES_SUPPORTED_SRS_URN);
        StringTokenizer st = new StringTokenizer(
                urns,
                DiggsConstants.CONFIGURATION_PROPERTIES_SPPORTED_SRS_URN_SEPARATOR);
        List<String> supportedSRSURNs = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            supportedSRSURNs.add(st.nextToken());
        }

        // return
        return supportedSRSURNs;
    }

    /**
     * Returns the dimension for the specified SRS name
     * 
     * @param srsName
     * @return
     * @throws Exception
     */
    public String getDimensionFromSRS(String srsName) throws Exception {

        if (srsName == null || srsName.isEmpty()) {
            System.err
                    .println("WARNING: srsName not found. SRS will be ignored");
            // throw new Exception("srsName is null");
            return null;
        }

        CoordinateReferenceSystem crs = getCRSFromAuthorithyCode(srsName);

        if (crs == null) {
            throw new Exception("CRS not found for srsName='" + srsName + "'");
        }

        int dimension = crs.getCoordinateSystem().getDimension();
        return Integer.toString(dimension);
    }

    /**
     * Converts the KML coordinates from source to target
     * 
     * @param kmlTuple
     * @param sourceCRS
     * @param targetCRS
     * @return
     * @throws Exception
     */
    public String convertKMLTuple(String kmlTuple,
            CoordinateReferenceSystem sourceCRS,
            CoordinateReferenceSystem targetCRS) throws Exception {

        // System.out.println("kmlTuple: " + kmlTuple);
        // create cache key
        String cacheKey = createCacheKey(kmlTuple, sourceCRS, targetCRS);

        // did we already cache this
        if (transformationCache.containsKey(cacheKey)) {
            // already cached - return value
            // System.out.println("retrieving from cache " + cacheKey);
            return transformationCache.get(cacheKey);
        } else {
            // process and than cache

            // count total number of coordinate
            StringTokenizer stringTokenizer = new StringTokenizer(kmlTuple,
                    DiggsConstants.KML_COORDINATE_SEPARATOR);
            int totalNumberOfCoordinates = stringTokenizer.countTokens();
            // create new array
            double[][] coordinatesArray = new double[1][totalNumberOfCoordinates];

            // create array from coordinates
            for (int j = 0; j < totalNumberOfCoordinates; j++) {
                // add coordinate
                coordinatesArray[0][j] = Double.valueOf(stringTokenizer
                        .nextToken());
            }

            // Run conversion
            convertCoordinates(coordinatesArray, sourceCRS, targetCRS);

            // recreate string
            StringBuffer modifiedCoordinates = new StringBuffer();

            for (int i = 0; i < totalNumberOfCoordinates; i++) {
                if (i >= 1) {
                    modifiedCoordinates
                            .append(DiggsConstants.KML_COORDINATE_SEPARATOR);
                }

                // add coordinate
                modifiedCoordinates.append(coordinatesArray[0][i]);
            }

            String modifiedCoordinatesToString = modifiedCoordinates.toString();
            // System.out.println("modifiedCoordinates: " +
            // modifiedCoordinatesToString);

            // cache value
            // System.out.println("caching " + cacheKey);
            transformationCache.put(cacheKey, modifiedCoordinatesToString);
            // return
            return modifiedCoordinatesToString;
        }

    }

    /**
     * Creates a unique key to use for the cache
     * 
     * @param kmlTuple
     * @param sourceCRS
     * @param targetCRS
     * @return
     */
    private String createCacheKey(String kmlTuple,
            CoordinateReferenceSystem sourceCRS,
            CoordinateReferenceSystem targetCRS) {
        StringBuffer sb = new StringBuffer();
        sb.append(sourceCRS.getName().getCode().hashCode());
        sb.append(targetCRS.getName().getCode().hashCode());
        sb.append(kmlTuple.hashCode());

        return sb.toString();
    }

    /**
     * Creates a unique key to use for the cache
     * 
     * @param kmlTuple
     * @param srsName
     * @param targetCRS
     * @return
     */
    private String createCacheKey(String kmlTuple, String srsName,
            CoordinateReferenceSystem targetCRS) {
        StringBuffer sb = new StringBuffer();
        sb.append(srsName.hashCode());
        sb.append(targetCRS.getName().getCode().hashCode());
        sb.append(kmlTuple.hashCode());

        return sb.toString();
    }

    /**
     * Converts the specified coordinates into KML supported coordinates
     * 
     * @param coordinates
     *            the original coordinates
     * @param srsName
     *            the name of the source spatial reference system
     * @param srsDimensionAsString
     *            the dimension of the source spatial reference system
     * @return the list of coordinates as supported by KML
     * @throws Exception
     */
    public String convertToKML(String coordinates, String srsName,
            String srsDimensionAsString) throws Exception {

        // create cache key
        String cacheKey = createCacheKey(coordinates, srsName,
                kmlCoordinateReferenceSystem);

        // did we already cache this
        if (transformationCache.containsKey(cacheKey)) {
            // already cached - return value
            // System.out.println("retrieving from cache2 " + cacheKey);
            return transformationCache.get(cacheKey);
        } else {

            // load properties file if needed
            // loadPropertiesFiles();

            //
            // validate input
            //

            int srsDimension = Integer.parseInt(srsDimensionAsString);

            // TODO review the following
            // Again, this should be the same 26911_5703. In most cases, a DIGGS
            // instance will probably use the same SRS for geographic
            // coordinates
            // throughout, so it would be useful to have a single place where
            // that
            // can be specified in an instance, and then would serve as the
            // default
            // srs, unless overridden in any specific case, rather than having
            // to
            // specify
            // it for every geometry element. How would you suggest that be
            // done? I
            // don't
            // think we should presume a default SRS if none is specified in the
            // instance, however.

            // validate srsName
            if (srsName == null || srsName.isEmpty()) {
                System.out
                        .println("WARNING: srsName not found. The system will use "
                                + default2DSrsName
                                + " for 2D or "
                                + default3DSrsName + " for 3D coordinates");
                if (srsDimension == 3) {
                    srsName = default3DSrsName;
                } else {
                    srsName = default2DSrsName;
                }
            }

            // result
            String convertedString = null;

            // parse the input string and create a double[][] array where the
            // first element will contain as many elements as specified by
            // srsDimension
            // gml:pos and gml:posList coordinates are space separated values
            // usually (e.g. x y z x1 y1 z1)
            double[][] coordinatesArray = generateCoordinateTuplesFromGMLCoordinates(
                    coordinates, srsDimension);

            // execute transformation
            convertCoordinates(coordinatesArray, srsName,
                    kmlCoordinateReferenceSystem);

            // convertCoordinates(coordinatesArray, srsName,
            // DiggsConstants.KML_AUTHORITY_CODE);

            // convert result back to KML
            // KML coordinates are comma separated and tuples are space
            // separated
            // (e.g. x,y,z x1,y1,z1)
            convertedString = formatCoordinatesFromGMLToKML(coordinatesArray);

            // cache value
            // System.out.println("caching2 " + cacheKey);
            transformationCache.put(cacheKey, convertedString);

            return convertedString;
        }
    }

    /**
     * Converts the specified coordinates into the specified SRS
     * 
     * @param coordinates
     *            the original coordinates
     * @param srsName
     *            the name of the source spatial reference system
     * @param srsDimensionAsString
     *            the dimension of the source spatial reference system
     * @param targetSrsName
     *            the target srsname to convert the data to
     * @return the list of coordinates as supported by the specified SRS
     * @throws Exception
     */
    public String convertCoordinates(String coordinates, String srsName,
            String srsDimensionAsString, String targetSrsName) throws Exception {

        //
        // validate input
        //

        // TODO review the following
        // Again, this should be the same 26911_5703. In most cases, a DIGGS
        // instance will probably use the same SRS for geographic coordinates
        // throughout, so it would be useful to have a single place where that
        // can be specified in an instance, and then would serve as the default
        // srs, unless overridden in any specific case, rather than having to
        // specify
        // it for every geometry element. How would you suggest that be done? I
        // don't
        // think we should presume a default SRS if none is specified in the
        // instance, however.

        int srsDimension = Integer.parseInt(srsDimensionAsString);

        // validate srsName
        if (srsName == null || srsName.isEmpty()) {
            System.out
                    .println("WARNING: srsName not found. The system will use "
                            + default2DSrsName + " for 2D or "
                            + default3DSrsName + " for 3D coordinates");
            if (srsDimension == 3) {
                srsName = default3DSrsName;
            } else {
                srsName = default2DSrsName;
            }
        }

        // result
        String convertedString = null;

        // parse the input string and create a double[][] array where the
        // first element will contain as many elements as specified by
        // srsDimension
        // gml:pos and gml:posList coordinates are space separated values
        // usually (e.g. x y z x1 y1 z1)
        double[][] coordinatesArray = generateCoordinateTuplesFromGMLCoordinates(
                coordinates, srsDimension);

        // execute transformation
        if (targetSrsName.equals(worldUTMSrsName)) {
            convertCoordinates(coordinatesArray, srsName,
                    worldUTMreferenceSystem);
        } else {
            convertCoordinates(coordinatesArray, srsName, targetSrsName);
        }

        // convertCoordinates(coordinatesArray, srsName,
        // DiggsConstants.KML_AUTHORITY_CODE);

        // convert result back to KML
        // KML coordinates are comma separated and tuples are space separated
        // (e.g. x,y,z x1,y1,z1)
        convertedString = formatCoordinatesFromGMLToKML(coordinatesArray);

        return convertedString;
    }

    /**
     * Creates the coordinates array that will be transformed
     * 
     * @param gmlCoordinates
     *            the GML coordinates as a string {e.g 1 2 3 4 5 6} .
     *            Coordinates are space separated
     * @param srsDimension
     *            the
     * @return
     */
    public double[][] generateCoordinateTuplesFromGMLCoordinates(
            String gmlCoordinates, int srsDimension) {

        // count total number of coordinate
        StringTokenizer stringTokenizer = new StringTokenizer(gmlCoordinates,
                DiggsConstants.GML_COORDINATE_SEPARATOR);
        int totalNumberOfCoordinates = stringTokenizer.countTokens();

        // calculate the number of tuples
        int numberOfTuples = totalNumberOfCoordinates / srsDimension;

        // create new array
        double[][] coordinatesArray = new double[numberOfTuples][srsDimension];

        // process tuples
        for (int i = 0; i < numberOfTuples; i++) {
            // process coordinates
            for (int j = 0; j < srsDimension; j++) {
                // add coordinate
                coordinatesArray[i][j] = Double.valueOf(stringTokenizer
                        .nextToken());
            }
        }

        // return
        return coordinatesArray;
    }

    /**
     * Formats the coordinates array into the KML format. KML coordinates are
     * comma separated and tuples are space separated (e.g. x,y,z x1,y1,z1)
     * 
     * @param coordinatesArray
     * @return
     */
    public String formatCoordinatesFromGMLToKML(double[][] coordinatesArray) {

        // string KML coordinates
        StringBuffer kmlCoordinates = new StringBuffer();
        // boolean isFirstTuple
        boolean isFirstTuple = true;

        for (double[] coordinates : coordinatesArray) {
            if (!isFirstTuple) {
                // add space separator
                kmlCoordinates
                        .append(DiggsConstants.KML_COORDINATE_TUPLE_SEPARATOR);
            }

            // boolean isFirstCoordinate
            int coordinateIndex = 1;
            //

            // add each coordinate
            for (double coordinate : coordinates) {
                if (coordinateIndex > 1) {
                    kmlCoordinates
                            .append(DiggsConstants.KML_COORDINATE_SEPARATOR);
                }

                // add coordinate
                kmlCoordinates.append(coordinate);

                // set that we already processed the first coordinate
                coordinateIndex++;
            }

            // set that we already processed the first coordinate tuple
            isFirstTuple = false;
        }

        // return
        return kmlCoordinates.toString();
    }

    /**
     * Converts coordinates from sourceSRS to targetSRS
     * 
     * @param coordinates
     *            array of coordinates
     * @param sourceSRS
     *            the source SRS
     * @param targetSRS
     *            the target SRS
     * @throws Exception
     */
    public void convertCoordinates(double[][] coordinates, String sourceSRS,
            String targetSRS) throws Exception {

        // Set SourceCRS
        CoordinateReferenceSystem sourceCRS = getCRSFromAuthorithyCode(sourceSRS);
        // Set TargetCRS
        CoordinateReferenceSystem targetCRS = getCRSFromAuthorithyCode(targetSRS);
        // transform
        try {
            convertCoordinates(coordinates, sourceCRS, targetCRS);
        } catch (FactoryException fe) {
            String errorMessage = "Cannot create a coordinate operation from "
                    + sourceSRS + " to " + targetSRS + ". Exception is:\n "
                    + fe.getLocalizedMessage();

            throw new Exception(errorMessage, fe);
        } catch (TransformException te) {

            String errorMessage = "Cannot create transformation from "
                    + sourceSRS + " to " + targetSRS + ". Error is:\n "
                    + te.getLocalizedMessage();

            throw new Exception(errorMessage, te);
        }
    }

    /**
     * Converts coordinates from sourceSRS to targetSRS
     * 
     * @param coordinates
     *            array of coordinates
     * @param sourceSRS
     *            the source SRS
     * @param targetSRS
     *            the target SRS
     * @throws Exception
     */
    public void convertCoordinates(double[][] coordinates, String sourceSRS,
            CoordinateReferenceSystem targetCRS) throws Exception {

        // Set SourceCRS
        CoordinateReferenceSystem sourceCRS = getCRSFromAuthorithyCode(sourceSRS);
        // transform
        try {
            convertCoordinates(coordinates, sourceCRS, targetCRS);
        } catch (FactoryException fe) {
            String errorMessage = "Cannot create a coordinate operation from "
                    + sourceSRS + " to " + targetCRS.getName()
                    + ". Exception is:\n " + fe.getLocalizedMessage();

            throw new Exception(errorMessage, fe);
        } catch (TransformException te) {

            String errorMessage = "Cannot create transformation from "
                    + sourceSRS + " to " + targetCRS.getName()
                    + ". Exception is:\n " + te.getLocalizedMessage();

            throw new Exception(errorMessage, te);
        }
    }

    /**
     * Converts coordinates from sourceSRS to targetSRS
     * 
     * @param coordinates
     *            array of coordinates
     * @param sourceCRS
     *            the source CRS
     * @param targetCRS
     *            the target CRS
     * @throws Exception
     */
    public void convertCoordinates(double[][] coordinates,
            CoordinateReferenceSystem sourceCRS,
            CoordinateReferenceSystem targetCRS) throws Exception {

        // load properties file if needed
        // loadPropertiesFiles();

        try {

            // the coordinate operation
            CoordinateOperation coordinateOperation = null;
            // the vertical coordinate operation to use if necessary
            CoordinateOperation verticalCoordinateOperation = null;

            // TODO the following process might need to be reviewed

            try {
                // try to create the operation from existing geotools operations
                coordinateOperation = operationFactory.createOperation(
                        sourceCRS, targetCRS);
            } catch (FactoryException fe) {

                // if no factory is found, check if the source is a CompoundCRS
                if (sourceCRS instanceof CompoundCRS
                        && targetCRS instanceof CompoundCRS) {

                    //
                    // create horizontal transformation
                    //

                    // retrieve the HorizontalCRS
                    SingleCRS sourceSingleCRS = CRS.getHorizontalCRS(sourceCRS);
                    // retrieve the HorizontalCRS
                    SingleCRS targetSingleCRS = CRS.getHorizontalCRS(targetCRS);

                    // create coordinateOperation
                    coordinateOperation = operationFactory.createOperation(
                            sourceSingleCRS, targetSingleCRS);

                    //
                    // create vertical transformation
                    //
                    // retrieve the VerticalCRS
                    VerticalCRS sourceVerticalCRS = CRS
                            .getVerticalCRS(sourceCRS);
                    // retrieve the VerticalCRS
                    VerticalCRS targetVerticalCRS = CRS
                            .getVerticalCRS(targetCRS);

                    // check that both datum are the same

                    // create coordinateOperation
                    try {
                        verticalCoordinateOperation = operationFactory
                                .createOperation(sourceVerticalCRS,
                                        targetVerticalCRS);
                    } catch (FactoryException fe1) {
                        throw fe1;
                    }

                } else if (CRS.getHorizontalCRS(sourceCRS)
                        .getCoordinateSystem().getDimension() == 2
                        && targetCRS instanceof CompoundCRS) {

                    //
                    // create horizontal transformation
                    //

                    // retrieve the HorizontalCRS
                    SingleCRS sourceSingleCRS = CRS.getHorizontalCRS(sourceCRS);
                    // retrieve the HorizontalCRS
                    SingleCRS targetSingleCRS = CRS.getHorizontalCRS(targetCRS);

                    // create coordinateOperation
                    coordinateOperation = operationFactory.createOperation(
                            sourceSingleCRS, targetSingleCRS);
                } else {
                    System.out.println("sourceCRS " + sourceCRS.getClass());
                    System.out.println("targetCRS " + targetCRS.getClass());
                    System.out.println("NOT YET IMPLEMENTED");
                }

                // throw fe;
            }

            // if no coordinateOperation was create, throw exception
            if (coordinateOperation == null) {

                System.out.println("coordinateOperation is NULLLLLLLLLLLL");

                String errorMessage = "Cannot create a coordinate operation from "
                        + sourceCRS.getName()
                        + " to "
                        + targetCRS.getName()
                        + ".";

                throw new Exception(errorMessage);
            }

            // create math transformation;
            MathTransform transform = coordinateOperation.getMathTransform();
            // create vertical transformation if necessary
            MathTransform verticalTransform = null;
            if (verticalCoordinateOperation != null) {
                verticalTransform = verticalCoordinateOperation
                        .getMathTransform();
            }

            for (double[] tuple : coordinates) {
                // Transform single tuple. Results output to same tuple
                // Parameters here are
                // double[] srcPts,
                // int srcOff,
                // double[] dstPts,
                // int dstOff,
                // int numPts

                // apply horizontal transformation
                transform.transform(tuple, 0, tuple, 0, 1);
                // apply vertical transformation if necessary
                if (verticalTransform != null) {
                    verticalTransform.transform(tuple, 0, tuple, 0, 1);
                }

            }

        } catch (FactoryException fe) {
            String errorMessage = "Cannot create a coordinate operation from "
                    + sourceCRS.getName() + " to " + targetCRS.getName()
                    + ". Exception is:\n " + fe.getLocalizedMessage();

            throw new Exception(errorMessage);
        } catch (TransformException te) {

            String errorMessage = "Cannot create transformation from "
                    + sourceCRS.getName() + " to " + targetCRS.getName()
                    + ". Exception is:\n " + te.getLocalizedMessage();

            throw new Exception(errorMessage);
        }
    }

    /**
     * Returns the known CRS from the authority code
     * 
     * @param crsAuthorithyCode
     * @return
     * @throws Exception
     */
    public CoordinateReferenceSystem getCRSFromAuthorithyCode(
            String crsAuthorithyCode) throws Exception {

        // load properties file if needed
        // loadPropertiesFiles();

        // the CoordinateReferenceSystem to return
        CoordinateReferenceSystem crs = null;

        try {

            // Check if there is an EPSG code mapped to this authority code
            if (!authorityCode2EPSGCode.containsKey(crsAuthorithyCode)) {
                // there is NO EPSG code mapped to this authority code

                // check if we can remove the authority's code URN and
                // generate a new authority code (this new code can either be an
                // EPSG code or a key for a defined WKT)
                // if we can't remove the URN, the initial authority code will
                // be returned
                String newCrsAuthorithyCode = removeSupportedURNs(crsAuthorithyCode);

                // check if the new authority code is a key for a defined WKT
                if (authorityCode2Wkt.containsKey(newCrsAuthorithyCode)) {
                    // the new authority code is a key for a defined WKT

                    // retrieve WKT
                    String wkt = (String) authorityCode2Wkt
                            .get(newCrsAuthorithyCode);
                    // create CoordinateReferenceSystem
                    BasicFactories basicFactories = new BasicFactories(null);
                    CRSFactory factory = basicFactories.getCRSFactory();
                    if (factory != null) {
                        crs = factory.createFromWKT(wkt);
                    }

                } else {
                    // the new authority code is NOT a key for a defined WKT
                    // try creating CoordinateReferenceSystem from the new
                    // authority code
                    crs = createCoordinateReferenceSystemFromEPSGCode(newCrsAuthorithyCode);
                }

            } else {
                // there is an EPSG code mapped to this authority code
                // lets retrieved the mapped EPSG code
                String epsgCode = (String) authorityCode2EPSGCode
                        .get(crsAuthorithyCode);

                // create CoordinateReferenceSystem from EPSG code
                crs = createCoordinateReferenceSystemFromEPSGCode(epsgCode);
            }

        } catch (FactoryRegistryException e) {
            String errorMessage = "Factory not found.";

            throw new Exception(errorMessage);

        } catch (Exception e) {
            String errorMessage = "Internal exception: " + e;
            e.printStackTrace();

            throw new Exception(errorMessage);

        }

        if (crs == null) {
            String errorMessage = "CRS [" + crsAuthorithyCode
                    + "] is not supported. Add the specified CRS to the list.";

            throw new Exception(errorMessage);
        }

        return crs;
    }

    /**
     * Creates the CoordinateReferenceSystem associated to this epsgCode
     * 
     * @param epsgCode
     * @return
     * @throws Exception
     */
    private CoordinateReferenceSystem createCoordinateReferenceSystemFromEPSGCode(
            String epsgCode) throws Exception {
        try {
            // check if the epsgCode is prefixed appropriately
            if (epsgCode != null
                    && !epsgCode.startsWith(DiggsConstants.EPSG_CODE_PREFIX)) {
                epsgCode = DiggsConstants.EPSG_CODE_PREFIX + epsgCode;
            }

            if (epsgcrsAuthorithyFactory != null) {
                // retrieve from HSQL factory when possible
                return epsgcrsAuthorithyFactory
                        .createCoordinateReferenceSystem(epsgCode);
            } else {
                return null;
            }

        } catch (FactoryException e) {
            String errorMessage = "CRS [" + epsgCode
                    + "] is not supported. Add the specified CRS to the list. "
                    + e.getMessage();

            throw new Exception(errorMessage);
        }
    }

    /**
     * Retieves the code from the authority code if the authority code starts
     * with one of the supported URNs. For example, if
     * authorityCode='urn:diggs:def:crs:DIGGS:0.1:32662_5713' and
     * 'urn:diggs:def:crs:DIGGS:0.1:' is supported than the returned value is
     * '32662_5713'. Otherwise the input authority code will be returned.
     * 
     * @param authorityCode
     * @return the code from the authority code if the authority code starts
     *         with one of the supported URNs. For example, if
     *         authorityCode='urn:diggs:def:crs:DIGGS:0.1:32662_5713' and
     *         'urn:diggs:def:crs:DIGGS:0.1:' is supported than the returned
     *         value is '32662_5713'. Otherwise the input authority code will be
     *         returned.
     */
    private String removeSupportedURNs(String authorityCode) {

        // if crsAuthorithyCode='urn:diggs:def:crs:DIGGS:0.1:32662_5713'
        // than newCrsAuthorithyCode='32662_5713'

        // for all support SRS URNs
        for (String supportedSRSURN : supportedSRSURNs) {
            // if the authority code starts with a supported SRS URN
            if (authorityCode.startsWith(supportedSRSURN)) {
                // extract the code
                authorityCode = authorityCode.replace(supportedSRSURN, "");
                break;
            }
        }

        // return
        return authorityCode;
    }

    /**
     * Returns the kmlCoordinateReferenceSystem
     * 
     * @return the kmlCoordinateReferenceSystem
     */
    public CoordinateReferenceSystem getKmlCoordinateReferenceSystem() {
        return kmlCoordinateReferenceSystem;
    }

    /**
     * Returns the worldUTMreferenceSystem
     * 
     * @return the worldUTMreferenceSystem
     */
    public CoordinateReferenceSystem getWorldUTMreferenceSystem() {
        return worldUTMreferenceSystem;
    }

}
