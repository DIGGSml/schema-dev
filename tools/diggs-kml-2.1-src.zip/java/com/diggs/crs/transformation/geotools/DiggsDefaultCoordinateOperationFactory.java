package com.diggs.crs.transformation.geotools;

import org.geotools.factory.Hints;
import org.geotools.referencing.operation.DefaultCoordinateOperationFactory;
import org.opengis.referencing.FactoryException;
import org.opengis.referencing.crs.VerticalCRS;
import org.opengis.referencing.cs.VerticalCS;
import org.opengis.referencing.operation.CoordinateOperation;
import org.opengis.referencing.operation.Matrix;

public class DiggsDefaultCoordinateOperationFactory extends
        DefaultCoordinateOperationFactory {

    public DiggsDefaultCoordinateOperationFactory(Hints hints) {
        super(hints);
    }

    @Override
    protected CoordinateOperation createOperationStep(VerticalCRS sourceCRS,
            VerticalCRS targetCRS) throws FactoryException {
        // VerticalDatum sourceDatum = sourceCRS.getDatum();
        // VerticalDatum targetDatum = targetCRS.getDatum();
        // if (!CRS.equalsIgnoreMetadata(sourceDatum, targetDatum)) {
        // throw new OperationNotFoundException(getErrorMessage(sourceDatum,
        // targetDatum));
        // }
        VerticalCS sourceCS = sourceCRS.getCoordinateSystem();
        VerticalCS targetCS = targetCRS.getCoordinateSystem();
        Matrix matrix = swapAndScaleAxis(sourceCS, targetCS);
        return createFromAffineTransform(AXIS_CHANGES, sourceCRS, targetCRS,
                matrix);
    }

}
