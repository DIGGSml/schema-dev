package com.diggs.crs.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.diggs.DiggsConstants;

/**
 * This class will load the properties file
 * 
 */
public class PropertiesLoader {

    /**
     * Map of supported and defined Coordinate Reference Systems (CRS). Key is
     * Authority Code, Value is CRS definition as WKT.
     */
    private Properties authorityCode2Wkt = new Properties();

    /**
     * Map of supported and defined Coordinate Reference Systems (CRS). Key is
     * Authority Code, Value is EPSG code
     */
    private Properties authorityCode2EPSGCode = new Properties();

    /**
     * Global DIGGS configuration file
     */
    private Properties configuration = new Properties();

    private PropertiesLoader(String configurationFolder) throws IOException {
        try {

            //
            // Load global configuration file
            //

            loadPropertiesFile(configurationFolder,
                    DiggsConstants.CONFIGURATION_PROPERTIES, false,
                    configuration);

            //
            // load CRS to WKT mapping file
            //

            // retrieve name of the WKT mapping file
            String wktPropertiesFileName = configuration
                    .getProperty(DiggsConstants.CONFIGURATION_PROPERTIES_WKT_PROPERTIES_FILE);

            loadPropertiesFile(configurationFolder, wktPropertiesFileName,
                    false, authorityCode2Wkt);

            //
            // load CRS to EPSG code mapping file
            //
            loadPropertiesFile(configurationFolder,
                    DiggsConstants.CRS2EPSG_PROPERTIES_FILE_XML, true,
                    authorityCode2EPSGCode);

        } catch (IOException e) {
            String errorMessage = "Failed to load configuration files. "
                    + e.getMessage();
            throw new IOException(errorMessage);
        }
    }

    /**
     * Returns the singleton instance of this class
     * 
     * @param configurationFolder
     *            configuration folde to load
     * @return
     * @throws IOException
     */
    public static PropertiesLoader load(String configurationFolder)
            throws IOException {
        return new PropertiesLoader(configurationFolder);
    }

    /**
     * Loads the specified properties file. This method will attempt to load it
     * from the specified conf folder first. If the file is not found in the
     * /conf folder, this method will attempt to load it from the classloader
     * root folder
     * 
     * @param configurationFolder
     * @param fileName
     *            the name of the properties file
     * @param isXML
     *            boolean that specifies if the propertied file is an XML file
     *            or not
     * @param properties
     *            the properties object to populate with the content of the
     *            properties file
     * @throws IOException
     */
    private void loadPropertiesFile(String configurationFolder,
            String fileName, boolean isXML, Properties properties)
            throws IOException {
        // instance
        InputStream is = null;
        // try to load from the conf folder
        File f = new File(configurationFolder + File.separator + fileName);

        // if not found, try to load from classloader root folder (e.g. for unit
        // tests, etc.)
        if (f == null || !f.exists()) {
            // load from root
            URL url = this.getClass().getClassLoader().getResource(fileName);
            is = url.openStream();
        } else {
            // new file input stream
            is = new FileInputStream(f);
        }

        // load properties
        if (isXML) {
            // load as XML properties
            properties.loadFromXML(is);
        } else {
            // load as normal properties
            properties.load(is);
        }

        // close the stream after loading the properties file
        is.close();

    }

    /**
     * Returns the authorityCode2Wkt
     * 
     * @return the authorityCode2Wkt
     */
    public Properties getAuthorityCode2Wkt() {
        return authorityCode2Wkt;
    }

    /**
     * Returns the authorityCode2EPSGCode
     * 
     * @return the authorityCode2EPSGCode
     */
    public Properties getAuthorityCode2EPSGCode() {
        return authorityCode2EPSGCode;
    }

    /**
     * Returns the configuration
     * 
     * @return the configuration
     */
    public Properties getConfiguration() {
        return configuration;
    }

}
