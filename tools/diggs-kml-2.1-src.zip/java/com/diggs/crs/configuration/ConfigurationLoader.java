package com.diggs.crs.configuration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import net.sf.saxon.Configuration;
import net.sf.saxon.PreparedStylesheet;
import net.sf.saxon.TransformerFactoryImpl;

import com.diggs.DiggsConstants;

/**
 * This class will load the properties file
 * 
 */
public class ConfigurationLoader {

    /**
     * Singleton instance of ConfigurationLoader
     */
    private static ConfigurationLoader instance;

    /**
     * Absolute path to the configuration folder
     */
    private String configurationFolderPath;

    /**
     * Object containing all the pre-loaded properties files
     */
    private PropertiesLoader propertiesFiles;

    /**
     * The stylesheet that generates a copy of the input GML file with
     * transformed coordinates
     */
    private PreparedStylesheet coordinateTransformationStylesheet;

    /**
     * The world UTM srsName to use for transforming all coordinates to
     * (Meter,Meter,Meter)
     */
    private String worldUTMSrsName;

    /**
     * Boolean that specifies if the temporary outpouts (*.kml file, img folder)
     * should be removed
     */
    private boolean removeTemporaryOutputs;

    /**
     * The Saxon transformation factory
     */
    private static TransformerFactoryImpl transformerFactoryImpl;

    private ConfigurationLoader(String configurationFolderPath)
            throws Exception {
        // current configuration folder
        this.configurationFolderPath = configurationFolderPath;
        // pre-load properties file
        this.propertiesFiles = PropertiesLoader.load(configurationFolderPath);
        // TODO pre-load stylesheets
        this.coordinateTransformationStylesheet = loadCoordinateTransformationStylesheet();
        // Retrieve the srs to use for transforming all coordinates to
        // (Meter,Meter,Meter)
        worldUTMSrsName = propertiesFiles.getConfiguration().getProperty(
                DiggsConstants.CONFIGURATION_PROPERTIES_WORLD_UTM_SRSNAME);
        // Retrieve the remove temporary output configuration property
        String temp = propertiesFiles
                .getConfiguration()
                .getProperty(
                        DiggsConstants.CONFIGURATION_PROPERTIES_REMOVE_TEMPORARY_OUTPUT);
        if (temp != null && temp.equals("true")) {
            removeTemporaryOutputs = true;
        } else {
            removeTemporaryOutputs = false;
        }

    }

    /**
     * Returns the singleton instance of this class
     * 
     * @return
     * @throws Exception
     */
    public static ConfigurationLoader getInstance(String configurationFolderPath)
            throws Exception {
        if (instance == null) {
            // no configuration have been loaded
            instance = new ConfigurationLoader(configurationFolderPath);
        } else if (!instance.configurationFolderPath
                .equals(configurationFolderPath)) {
            // the specified configuration folder is different from the one
            // currently loaded let's reload the configuration files from the
            // new specified folder
            instance = new ConfigurationLoader(configurationFolderPath);
        } else {
            // otherwise nothing to do, we already loaded the configuration file
            // from the specified configuration folder
        }

        return instance;
    }

    /**
     * Returns the singleton instance of this class
     * 
     * @return
     * @throws IOException
     */
    public static ConfigurationLoader getInstance() throws IOException {
        return instance;
    }

    /**
     * Loads the transformation factory
     * 
     * @return
     */
    private static TransformerFactoryImpl loadTransformerFactoryImpl() {
        // create global configuration
        Configuration config = new Configuration();
        config.setAllNodesUntyped(true);
        config.setVersionWarning(true);
        return new TransformerFactoryImpl(config);
    }

    private PreparedStylesheet loadCoordinateTransformationStylesheet()
            throws Exception {
        String preProcessXSLTFilePath = configurationFolderPath
                + File.separator + DiggsConstants.CONF_XSL_FOLDER
                + File.separator
                + DiggsConstants.CONF_XSL_SRS_CONVERTER_FILE_NAME;
        return getStyleSheet(preProcessXSLTFilePath);
    }

    /**
     * Validates that the stylesheet exists and and returns it as
     * PreparedStylesheet object
     * 
     * @param xsltFilePath
     * @param factory
     * @return
     * @throws Exception
     */
    public static PreparedStylesheet getStyleSheet(String xsltFilePath)
            throws Exception {
        File xsltFile = new File(xsltFilePath);
        if (xsltFile == null || !xsltFile.exists()) {
            throw new Exception("XSLT file not found");
        }
        Source styleSource = new StreamSource(xsltFile);
        return (PreparedStylesheet) getTransformerFactoryImpl().newTemplates(
                styleSource);
    }

    /**
     * Creates the list of parameter to pass to the KML Styling XSLT
     * 
     * @param configurationFolderPath
     * @param imageryFolderPath
     * @return
     * @throws Exception
     */
    public ArrayList<String> createKMLStylingParameters(String imageryFolderPath)
            throws Exception {
        ArrayList<String> parameterList = new ArrayList<String>();

        // System.out.println("Configuration folder path: " +
        // configurationFolderPath);
        // System.out.println("KML styling file path: " +
        // configurationFolderPath
        // + File.separator + DiggsConstants.KML_STYLING_FILE_NAME);

        // create KML Styling file location
        String kmlStylingFileFullPath = configurationFolderPath
                + File.separator + DiggsConstants.KML_STYLING_FILE_NAME;
        File kmlStylingFile = new File(kmlStylingFileFullPath);
        if (kmlStylingFile == null || !kmlStylingFile.exists()) {
            throw new Exception("Styling file not found");
        }

        // Make relative pathnames absolute
        File tempFile = new File(kmlStylingFileFullPath);
        if (!tempFile.isAbsolute()) {
            kmlStylingFileFullPath = tempFile.getParentFile()
                    .getCanonicalPath() + File.separator + tempFile.getName();
        }
        
        // replace backslashes with forward slashes - XSLT cannot find the file
        // otherwise
        // TODO need to test this on mac/linux
        kmlStylingFileFullPath = kmlStylingFileFullPath.replaceAll("\\\\", "/");

        // create parameter
        String kmlStylingFileFullPathParameter = createXSLTParameter(
                DiggsConstants.XSLT_PARAMETER_KML_STYLING_FILE,
                kmlStylingFileFullPath);
        // add the DIGGS-KML Styling spreadsheet as an input
        parameterList.add(kmlStylingFileFullPathParameter);

        // TODO need to test this on mac
        imageryFolderPath = imageryFolderPath.replaceAll("\\\\", "/");
        // create parameter
        String imageryFolderFullPathParameter = createXSLTParameter(
                DiggsConstants.TARGET_IMAGERY_FOLDER, imageryFolderPath);
        // add the target imagery folder
        parameterList.add(imageryFolderFullPathParameter);

        return parameterList;
    }

    /**
     * Creates the list of parameter to pass to the SRS conversion XSLT
     * 
     * @param targetSrs
     * @return
     * @throws Exception
     */
    public ArrayList<String> createSRSParameter(String targetSrs)
            throws Exception {
        ArrayList<String> parameterList = new ArrayList<String>();

        // create target parameter
        if (targetSrs != null) {
            String targetSrsParameter = createXSLTParameter(
                    DiggsConstants.XSLT_PARAMETER_TARGET_SRS_NAME, targetSrs);
            // add the DIGGS-KML Styling spreadsheet as an input
            parameterList.add(targetSrsParameter);
        }

        return parameterList;
    }

    /**
     * Creates an XSLT parameter(e.g. key=value)
     * 
     * @param key
     * @param value
     * @return
     */
    public String createXSLTParameter(String key, String value) {
        return key + "=" + value;
    }

    /**
     * Returns the propertiesFiles
     * 
     * @return the propertiesFiles
     */
    public PropertiesLoader getPropertiesFiles() {
        return propertiesFiles;
    }

    /**
     * Returns the transformerFactoryImpl
     * 
     * @return the transformerFactoryImpl
     */
    public static TransformerFactoryImpl getTransformerFactoryImpl() {
        if (transformerFactoryImpl == null) {
            transformerFactoryImpl = loadTransformerFactoryImpl();
        }

        return transformerFactoryImpl;
    }

    /**
     * Returns the coordinateTransformationStylesheet
     * 
     * @return the coordinateTransformationStylesheet
     */
    public PreparedStylesheet getCoordinateTransformationStylesheet() {
        return coordinateTransformationStylesheet;
    }

    /**
     * Returns the worldUTMSrsName
     * 
     * @return the worldUTMSrsName
     */
    public String getWorldUTMSrsName() {
        return worldUTMSrsName;
    }

    /**
     * Returns the removeTemporaryOutputs
     * 
     * @return the removeTemporaryOutputs
     */
    public boolean isRemoveTemporaryOutputs() {
        return removeTemporaryOutputs;
    }

}
