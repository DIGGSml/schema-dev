package com.diggs.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import net.sf.saxon.PreparedStylesheet;
import net.sf.saxon.Transform;

import com.diggs.DiggsConstants;
import com.diggs.crs.configuration.ConfigurationLoader;
import com.diggs.crs.transformation.geotools.GTCoordinateTransformer;

public class XSLTExecutor {

    /**
     * Trace destination
     */
    private static PrintStream traceDestination = System.err;

    public static void execute(String inputFilePath, String xsltFilePath,
            String outputFilePath, String configurationFolderPath)
            throws Exception {

        // System.out.println("Configuration directory path: " +
        // configurationFolderPath);
        // System.out.println("XSLT file path: " + xsltFilePath);
        // System.out.println("Input file path: " + inputFilePath);
        // System.out.println("Output file path: " + outputFilePath);

        // load configuration file and cache for subsequent requests
        ConfigurationLoader configurationLoader = ConfigurationLoader
                .getInstance(configurationFolderPath);
        // clear current geometry cache
        GTCoordinateTransformer.getInstance().clearGeometryCache();

        // new instance
        Transform transform = new Transform();

        // load source file
        Source source = getSourceFile(inputFilePath);
        // load stylesheet
        PreparedStylesheet sheet = ConfigurationLoader
                .getStyleSheet(xsltFilePath);
        // prepare outputFile
        File outputFile = new File(outputFilePath);
        // prepare intermediate file
        File intermediateFile = new File(outputFilePath
                + DiggsConstants.INTERMEDIATE_FILE_SUFFIX);

        // create imageryFolderPath
        String targetFolderPath = outputFile.getParent();
        String imageryFolderPath = targetFolderPath + File.separator
                + DiggsConstants.CONF_IMG_FOLDER;

        // create parameters
        ArrayList<String> parameterList = configurationLoader
                .createKMLStylingParameters(imageryFolderPath);

        try {

            long start = System.currentTimeMillis();

            //
            // pre-process transformation
            //

            // load stylesheet the pre-process stylesheet
            PreparedStylesheet preProcessSheet = configurationLoader
                    .getCoordinateTransformationStylesheet();

            // convert source file coordinates to KML
            transform
                    .processFile(
                            source,
                            preProcessSheet,
                            intermediateFile,
                            configurationLoader
                                    .createSRSParameter(DiggsConstants.KML_COMPOUND_CRS_NAME),
                            null, null, traceDestination);

            //
            // KML styling transformation
            //

            // transform to KML
            Source intermediateFileAsSource = new StreamSource(intermediateFile);
            transform.processFile(intermediateFileAsSource, sheet, outputFile,
                    parameterList, null, null, traceDestination);

            System.out.println("XSLT Processing time = "
                    + (System.currentTimeMillis() - start) + "ms");

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
            // delete temp file if any
            if (intermediateFile != null && intermediateFile.exists()) {
                intermediateFile.delete();
            }

            // throw exception
            throw e;
        }

        // TODO how do we make sure that we don't overwrite the fetched images

        // copy image files in the output folder if necessary
        // File targetFolder = outputFile.getParentFile();
        // copyImages(configurationFolderPath, targetFolder);

        // delete temp file if any
        if (intermediateFile != null && intermediateFile.exists()) {
            intermediateFile.delete();
        }

    }

    // private Source preProcessInputFile(){
    //
    // }

    /**
     * Validates that the source file exists and returns it as a Source object
     * 
     * @param inputFilePath
     * @throws Exception
     */
    public static Source getSourceFile(String inputFilePath) throws Exception {
        File inputFile = new File(inputFilePath);
        if (inputFile == null || !inputFile.exists()) {
            throw new Exception("Source file not found");
        }
        return new StreamSource(inputFile);
    }

    /**
     * Copy all images from the source folder to target folder
     * 
     * @param configurationFolderPath
     * @param targetFolder
     */
    public static void copyImages(String configurationFolderPath,
            File targetFolder) {

        // check the source image folder exists
        String srcImageFolderPath = configurationFolderPath + File.separator
                + DiggsConstants.CONF_IMG_FOLDER;

        File srcImageFolder = new File(srcImageFolderPath);

        if (srcImageFolder == null || !srcImageFolder.exists()) {
            System.err.println("Source image folder doesn't exist");
            return;
        }

        // create target Image folder if necessary
        String targetImageFolderPath = targetFolder.getAbsolutePath()
                + File.separator + DiggsConstants.CONF_IMG_FOLDER;
        File targetImageFolder = new File(targetImageFolderPath);
        if (!targetImageFolder.exists()) {
            // create new target folder if it doesnt'exist
            targetImageFolder.mkdir();
        }

        for (File srcImage : srcImageFolder.listFiles()) {
            // only copy files for now, no folder
            if (srcImage.isFile()) {
                copyFile(targetImageFolderPath, srcImage);
            }
        }

    }

    /**
     * Copys the source file in teh target folder if the fiel doesn't already
     * exist
     * 
     * @param outputFolder
     * @param srcFile
     */
    public static void copyFile(String outputFolder, File srcFile) {

        // if the target already contains a file with this name, skip copy
        String targetFilePath = outputFolder + File.separator
                + srcFile.getName();
        File trgFile = null;

        if ((trgFile = new File(targetFilePath)).exists()) {
            // file already exists, skip this
            return;
        }

        // File doesn't exist, copy file
        try {
            InputStream in = new FileInputStream(srcFile);
            OutputStream out = new FileOutputStream(trgFile);

            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
            // System.out.println("File copied.");
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.err.println("Unable to copy image to target folder");
        }

    }

    public static void removeTemporaryOutputs(String outputFilePath) {
        try {
            // should we delete the created *.kml and img folder
            if (ConfigurationLoader.getInstance().isRemoveTemporaryOutputs()) {

                // Did we create the output file
                File outputFile = new File(outputFilePath);

                // create imageryFolderPath
                String targetFolderPath = outputFile.getParent();
                String imageryFolderPath = targetFolderPath + File.separator
                        + DiggsConstants.CONF_IMG_FOLDER;
                File trgFileFolder = new File(imageryFolderPath);

                if (trgFileFolder.exists()) {
                    // boolean success = false;
                    // delete folder content
                    String[] children = trgFileFolder.list();
                    for (int i = 0; i < children.length; i++) {
                        new File(trgFileFolder, children[i]).delete();
                        // success = new File(trgFileFolder,
                        // children[i]).delete();
                        // System.out.println(success);
                    }
                    // delete folder
                    trgFileFolder.delete();
                    // success = trgFileFolder.delete();
                    // System.out.println(success);
                }

                //
                // Delete kml file
                //
                if (outputFile.exists()) {
                    // delete f
                    outputFile.delete();
                    // boolean result = outputFile.delete();
                    // System.out.println(result);
                }

            }
        } catch (Exception e) {
            System.out.println("Unable to remove temporary outputs");
        }
    }

}
