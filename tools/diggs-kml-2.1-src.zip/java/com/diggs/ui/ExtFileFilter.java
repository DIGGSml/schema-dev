package com.diggs.ui;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class ExtFileFilter extends FileFilter {
    private String[] masks;
    private String description;

    // example masks = ".kml;.kmz"
    public ExtFileFilter(String description, String masks) {
        this.description = description;
        this.masks = masks.toLowerCase().split(";");
    }

    @Override
    public boolean accept(File arg0) {

        // if the file is a folder, return true
        // so that we can browse for appropriate files
        if (arg0.isDirectory()) {
            return true;
        }

        String filename = arg0.getName();
        int i = filename.lastIndexOf('.');
        if (i < 0)
            return false;
        String ext = filename.substring(i).toLowerCase();
        for (String s : masks) {
            if (s.equals(ext))
                return true;
        }
        return false;
    }

    @Override
    public String getDescription() {
        return description;
    }
}
