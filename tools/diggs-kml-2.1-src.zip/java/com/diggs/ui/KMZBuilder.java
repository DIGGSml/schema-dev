package com.diggs.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class KMZBuilder {

    public static void addFile(ZipOutputStream zp, String folder, File file) {
        try {
            FileInputStream ii = new FileInputStream(file);
            String name = (folder == null) ? file.getName() : folder + "/"
                    + file.getName();
            ZipEntry ze = new ZipEntry(name);
            ze.setMethod(ZipEntry.DEFLATED);

            zp.putNextEntry(ze);
            byte[] buf = new byte[512];
            int rsz;

            while ((rsz = ii.read(buf, 0, 512)) > 0) {
                zp.write(buf, 0, rsz);
            }

            ii.close();
            zp.closeEntry();
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void addFolder(ZipOutputStream zp, String root, String folder) {
        try {
            File full = new File(root + "/" + folder);
            File[] files = full.listFiles();
            if (files != null) {
                for (File f : files) {
                    addFile(zp, folder, f);
                }
            }
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void execute(String kmlFile) throws Exception {
        // create KMZ file name
        String kmzFile = kmlFile.replaceAll("\\.[kK][mM][lL]$", ".kmz");

        // create ZIP stream
        FileOutputStream fp = new FileOutputStream(kmzFile);
        ZipOutputStream zp = new ZipOutputStream(fp);
        zp.setMethod(ZipOutputStream.DEFLATED);

        // add main kml file
        File fileKml = new File(kmlFile);
        addFile(zp, null, fileKml);

        // add sub-directory img
        String outputFilePath = fileKml.getParent();
        addFolder(zp, outputFilePath, "img");

        zp.close();
        fp.close();
    }
}
