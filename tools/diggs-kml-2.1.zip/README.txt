﻿DIGGS GML to KML Converter
==========================


Installation
------------

1) Install Java

  Download the appropriate package and follow the instructions to install the
  Java JDK <http://www.oracle.com/technetwork/java/javase/downloads/index.html>.

2) Set the JAVA_HOME Environment Variable

  When the installation is complete, add or update your JAVA_HOME environment
  variable to the JDK installation path.  In Windows, go to Start -> Control
  Panel -> System -> Advanced -> Environment Variables and create or update the
  JAVA_HOME system variable; e.g. JAVA_HOME=C:\Program Files\Java\jdk1.6.0_10.


Configuration
-------------

The default user properties (configuration directory, XSLT, input and output 
files) are automatically created or updated each time the user exits the 
application.  These properties are stored in the bin/configuration.props file.

Additional configuration parameters can be found in the config/ directory:

- configuration.properties
  Global application configuration properties (default CRS values, tile server, 
  temporary file management, etc).
  
- crsAuthorityCodeEPSGMapping.xml
  Maps custom CRS definitions to well-known CRS definitions (CRS to WKT).

- DIGGS_KML_STYLING.xml
  Styling rules that are applied to the conversion (KML styling rules).

- DIGGS_WKT_CRS_DICTIONARY.txt
  List of well-known text (WKT) CRS definitions.

Note that when a configuration property is changed the application needs to be
restarted.


Usage
-----

1) Run the Java application using the bin\launch.bat file (or bin\launch.sh in
  Linux).

2) Optionally, modify the configuration files (config/ directory) if needed.  
  See the list of configuration files above.

3) Select the appropriate configuration directory, XSLT, input and output* files 
  depending on what conversion is desired.

4) Click the Execute button.

5) Open the resulting KMZ file in Google Earth.

* Note that the output file should be given a "kml" extension, although the 
final output of the program is a "kmz" file (zipped kml) with the same name.


Support
-----

Tested for Diggs2.0.a schema and test instances.